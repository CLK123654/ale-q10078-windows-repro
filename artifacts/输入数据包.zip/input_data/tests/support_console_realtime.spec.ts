import { test } from '@playwright/test';

test('请完成客服会话工作台回归', async () => {
  throw new Error('请读取业务材料并完成浏览器用例');
});
