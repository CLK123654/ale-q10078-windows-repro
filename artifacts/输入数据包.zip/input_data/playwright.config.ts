import { defineConfig } from '@playwright/test';

throw new Error('请根据本题场景完成Playwright配置');

export default defineConfig({});
