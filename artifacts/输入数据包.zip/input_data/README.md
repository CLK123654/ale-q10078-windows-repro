# 客服会话工作台回归材料

app目录是本地客服会话页面。fixtures目录保存会话、坐席角色和Socket事件，cases目录列出五个发布场景，rules目录给出排序、固定时刻和截图名称。

请完成playwright.config.ts和tests/support_console_realtime.spec.ts。测试结果写入reports与artifacts。运行前先执行npm ci和npx playwright install chromium，再执行npm run test:e2e。

正式运行只访问本机静态服务。业务输入用于场景计算，不应由测试改写。