import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';

const root = process.cwd();
const dynamicPaths = ['reports', 'artifacts', '.playwright-results'];
for (const item of dynamicPaths) await fs.rm(path.join(root, item), { recursive: true, force: true });

const cli = path.join(root, 'node_modules', '@playwright', 'test', 'cli.js');
const child = spawn(process.execPath, [cli, 'test', '--config', 'playwright.config.ts'], {
  cwd: root,
  stdio: 'inherit',
  env: process.env,
});
const code = await new Promise((resolve) => child.on('exit', (value) => resolve(value ?? 1)));
process.exitCode = code;
