const priorityRank = { P1: 1, P2: 2, P3: 3 };
let conversations = [];
let activeQueue = null;

function sorted(rows) {
  return rows.slice().sort((left, right) =>
    priorityRank[left.priority] - priorityRank[right.priority]
      || left.first_response_due_utc.localeCompare(right.first_response_due_utc)
      || left.conversation_id.localeCompare(right.conversation_id));
}

function slaLabel(row) {
  const minutes = Math.round((Date.parse(row.first_response_due_utc) - Date.now()) / 60000);
  return minutes < 0 ? `逾期${Math.abs(minutes)}分钟` : `${minutes}分钟后到期`;
}

function currentRows() {
  return activeQueue ? conversations.filter((row) => row.queue === activeQueue) : conversations;
}

function render() {
  const list = document.querySelector('[data-testid=conversation-list]');
  list.replaceChildren();
  sorted(currentRows()).forEach((item, index) => {
    const card = document.createElement('button');
    card.className = 'conversation-card';
    card.dataset.conversationId = item.conversation_id;
    card.dataset.priority = item.priority;
    card.dataset.unread = String(item.unread);
    card.dataset.assignee = item.assignee;
    card.dataset.status = item.status;
    card.tabIndex = index === 0 ? 0 : -1;
    card.innerHTML = `<strong>${item.conversation_id} · ${item.customer}</strong><span>${item.priority}</span><span class="meta">${item.queue} · unread:${item.unread}</span><span class="sla" data-sla-for="${item.conversation_id}">${slaLabel(item)}</span>`;
    card.addEventListener('click', () => {
      const detail = document.querySelector('[data-testid=conversation-detail]');
      detail.dataset.openConversation = item.conversation_id;
      detail.dataset.transcriptCount = String(item.transcript_count);
      document.querySelector('[data-testid=detail-heading]').textContent = `${item.conversation_id} · ${item.customer}`;
    });
    list.appendChild(card);
  });
}

function applyFeed(event) {
  const row = conversations.find((item) => item.conversation_id === event.conversation_id);
  document.body.dataset.lastEventId = event.event_id;
  if (!row) return;
  if (event.type === 'message_received') row.unread += Number(event.unread_delta);
  if (event.type === 'priority_changed') row.priority = event.priority;
  if (event.type === 'assignment_changed') row.assignee = event.assignee;
  if (event.type === 'status_changed') row.status = event.status;
  render();
}

async function boot() {
  conversations = await fetch('/api/conversations').then((response) => response.json());
  document.querySelectorAll('[data-testid^=queue-]').forEach((button) => {
    button.addEventListener('click', () => {
      activeQueue = button.dataset.testid?.replace('queue-', '') ?? button.getAttribute('data-testid').replace('queue-', '');
      render();
    });
  });
  render();
  const socket = new WebSocket('ws://local.test/agent-feed');
  socket.addEventListener('message', (message) => applyFeed(JSON.parse(message.data)));
}

boot();
