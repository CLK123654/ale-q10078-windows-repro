import path from 'node:path';
import { defineConfig, devices } from '@playwright/test';

const port = process.env.ALE_PORT ?? '4173';

export default defineConfig({
  testDir: './tests',
  outputDir: path.resolve(process.cwd(), '.playwright-results'),
  timeout: 30000,
  expect: { timeout: 5000 },
  workers: 1,
  fullyParallel: false,
  retries: 0,
  reporter: [['line']],
  use: {
    baseURL: `http://127.0.0.1:${port}`,
    timezoneId: 'Asia/Shanghai',
    locale: 'zh-CN',
    viewport: { width: 1280, height: 900 },
    trace: 'retain-on-failure',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'node scripts/static_server.mjs',
    cwd: process.cwd(),
    url: `http://127.0.0.1:${port}/`,
    reuseExistingServer: false,
    timeout: 30000,
  },
});
