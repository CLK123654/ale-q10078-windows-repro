import { expect, test } from '@playwright/test';
import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const conversations = JSON.parse(fsSync.readFileSync(path.join(root, 'fixtures/conversations.json'), 'utf8'));
const feed = JSON.parse(fsSync.readFileSync(path.join(root, 'fixtures/socket_feed.json'), 'utf8'));
const roles = JSON.parse(fsSync.readFileSync(path.join(root, 'fixtures/agent_roles.json'), 'utf8'));
const contract = JSON.parse(fsSync.readFileSync(path.join(root, 'rules/console_contract.json'), 'utf8'));

function parseCsv(text) {
  const lines = text.trim().split(/\r?\n/u);
  const headers = lines.shift().split(',');
  return lines.map((line) => Object.fromEntries(line.split(',').map((value, index) => [headers[index], value])));
}

function csvCell(value) {
  const text = String(value ?? '');
  return /[",\r\n]/u.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function csvText(headers, rows) {
  return `${headers.join(',')}\n${rows.map((row) => headers.map((header) => csvCell(row[header])).join(',')).join('\n')}\n`;
}

const cases = parseCsv(fsSync.readFileSync(path.join(root, 'cases/realtime_cases.csv'), 'utf8'));
const caseRows = [];
const focusRows = [];

function eventsUntil(eventId) {
  const end = feed.findIndex((event) => event.event_id === eventId);
  return end < 0 ? [] : feed.slice(0, end + 1);
}

function routeRows(item) {
  const role = roles[item.role];
  if (!role) throw new Error(`缺少角色${item.role}`);
  const replay = eventsUntil(item.feed_until);
  const futurePriority = new Set(replay.filter((event) => event.type === 'priority_changed' && event.priority === item.priority).map((event) => event.conversation_id));
  return conversations.filter((row) => {
    const roleVisible = role.can_view_all_agents || row.assignee === role.agent_id || (role.can_view_unassigned && row.assignee === 'unassigned');
    const queueVisible = item.queue ? row.queue === item.queue : true;
    const priorityVisible = item.priority ? row.priority === item.priority || futurePriority.has(row.conversation_id) : true;
    return roleVisible && queueVisible && priorityVisible;
  });
}

const priorityRank = { P1: 1, P2: 2, P3: 3 };

function expectedRows(item) {
  const rows = structuredClone(routeRows(item));
  for (const event of eventsUntil(item.feed_until)) {
    const row = rows.find((entry) => entry.conversation_id === event.conversation_id);
    if (!row) continue;
    if (event.type === 'message_received') row.unread += Number(event.unread_delta);
    if (event.type === 'priority_changed') row.priority = event.priority;
    if (event.type === 'assignment_changed') row.assignee = event.assignee;
    if (event.type === 'status_changed') row.status = event.status;
  }
  return rows
    .filter((row) => item.queue ? row.queue === item.queue : true)
    .filter((row) => item.priority ? row.priority === item.priority : true)
    .sort((left, right) => priorityRank[left.priority] - priorityRank[right.priority]
      || left.first_response_due_utc.localeCompare(right.first_response_due_utc)
      || left.conversation_id.localeCompare(right.conversation_id));
}

function expectedSlaLabel(row) {
  const minutes = Math.round((Date.parse(row.first_response_due_utc) - Date.parse(contract.fixed_now_utc)) / 60000);
  return minutes < 0 ? `逾期${Math.abs(minutes)}分钟` : `${minutes}分钟后到期`;
}

async function installSocket(page, events) {
  await page.addInitScript((socketEvents) => {
    class LocalSocket extends EventTarget {
      static OPEN = 1;
      constructor(url) {
        super();
        this.url = url;
        this.readyState = LocalSocket.OPEN;
        this.started = false;
        queueMicrotask(() => this.dispatchEvent(new Event('open')));
      }
      addEventListener(type, listener, options) {
        super.addEventListener(type, listener, options);
        if (type === 'message' && !this.started) {
          this.started = true;
          socketEvents.forEach((event, index) => setTimeout(() => {
            this.dispatchEvent(new MessageEvent('message', { data: JSON.stringify(event) }));
          }, index * 15));
        }
      }
      send() {}
      close() { this.readyState = 3; }
    }
    window.WebSocket = LocalSocket;
  }, events);
}

async function visibleIds(page) {
  return page.locator('[data-conversation-id]').evaluateAll((nodes) => nodes.map((node) => node.dataset.conversationId));
}

test.describe.configure({ mode: 'serial' });

for (const item of cases) {
  test(item.case_id, async ({ page }) => {
    const replay = eventsUntil(item.feed_until);
    const externalRequests = [];
    page.on('request', (request) => {
      const url = new URL(request.url());
      if (!['127.0.0.1', 'localhost'].includes(url.hostname)) externalRequests.push(request.url());
    });
    await page.clock.setFixedTime(new Date(contract.fixed_now_utc));
    await page.route(`**${contract.route_path}`, async (route) => {
      await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(routeRows(item)) });
    });
    await installSocket(page, replay);
    await page.goto('/');
    await expect(page.getByTestId('conversation-list')).toBeVisible();
    if (replay.length) await expect(page.locator('body')).toHaveAttribute('data-last-event-id', replay.at(-1).event_id);
    if (item.queue && item.case_id !== 'CASE_KEYBOARD_REPLY') await page.getByTestId(`queue-${item.queue}`).click();

    const expected = expectedRows(item).map((row) => row.conversation_id);
    await expect(page.locator('[data-conversation-id]')).toHaveCount(expected.length);
    expect(await visibleIds(page)).toEqual(expected);
    for (const row of conversations.filter((entry) => !expected.includes(entry.conversation_id))) {
      await expect(page.locator(`[data-conversation-id=${row.conversation_id}]`)).toHaveCount(0);
    }

    let opened = '';
    let slaLabels = '';
    if (item.interaction === 'capture_billing') {
      const unreadEvent = replay.find((event) => event.event_id === 'S01');
      const source = conversations.find((row) => row.conversation_id === 'C1022');
      await expect(page.locator('[data-conversation-id=C1022]')).toHaveAttribute('data-unread', String(source.unread + unreadEvent.unread_delta));
      await page.screenshot({ path: path.join(root, contract.screenshot), fullPage: true });
    }
    if (item.interaction === 'inspect_priority') {
      await expect(page.locator('[data-conversation-id=C1014]')).toHaveAttribute('data-priority', 'P1');
      await expect(page.locator('[data-conversation-id=C1020]')).toHaveCount(1);
    }
    if (item.interaction === 'open_detail') {
      const target = page.locator(`[data-conversation-id=${item.detail_target}]`);
      await target.scrollIntoViewIfNeeded();
      await target.click();
      const detail = page.getByTestId('conversation-detail');
      const source = conversations.find((row) => row.conversation_id === item.detail_target);
      await expect(detail).toHaveAttribute('data-open-conversation', item.detail_target);
      await expect(detail).toHaveAttribute('data-transcript-count', String(source.transcript_count));
      opened = item.detail_target;
    }
    if (item.interaction === 'keyboard_reply') {
      const steps = [
        ['global-search', page.getByTestId('global-search'), '搜索会话'],
        ['queue-billing', page.getByTestId('queue-billing'), 'Billing'],
        ['conversation-C1011', page.locator('[data-conversation-id=C1011]'), 'Oren D.'],
        ['reply-editor', page.getByTestId('reply-editor'), '回复客户'],
        ['send-button', page.getByTestId('send-button'), '发送'],
      ];
      for (let index = 0; index < steps.length; index += 1) {
        await page.keyboard.press('Tab');
        await expect(steps[index][1]).toBeFocused();
        focusRows.push({ order_index: index + 1, locator: steps[index][0], label: steps[index][2] });
        if (index === 2) {
          await page.keyboard.press('Enter');
          await expect(page.getByTestId('conversation-detail')).toHaveAttribute('data-open-conversation', 'C1011');
          opened = 'C1011';
        }
      }
      await page.getByTestId('reply-editor').fill('');
      await page.getByTestId('reply-editor').press('Enter');
      await expect(page.getByTestId('conversation-detail')).toHaveAttribute('data-open-conversation', 'C1011');
    }
    if (item.interaction === 'read_sla') {
      const observed = [];
      for (const conversationId of ['C1008', 'C1022']) {
        const source = conversations.find((row) => row.conversation_id === conversationId);
        const expectedLabel = expectedSlaLabel(source);
        const actual = await page.locator(`[data-sla-for=${conversationId}]`).textContent();
        expect(actual).toBe(expectedLabel);
        observed.push(`${conversationId}=${actual}`);
      }
      slaLabels = observed.join('|');
    }
    caseRows.push({ case_id: item.case_id, role: item.role, observed_visible_ids: (await visibleIds(page)).join('|'), opened_conversation_id: opened, sla_labels: slaLabels });
    expect(externalRequests).toEqual([]);
  });
}

test.afterAll(async () => {
  const eventRows = feed.map((event) => {
    const source = conversations.find((row) => row.conversation_id === event.conversation_id);
    const fields = {
      message_received: ['unread', source.unread, source.unread + event.unread_delta],
      priority_changed: ['priority', source.priority, event.priority],
      assignment_changed: ['assignee', source.assignee, event.assignee],
      status_changed: ['status', source.status, event.status],
    };
    const [field, before, after] = fields[event.type];
    return { event_id: event.event_id, conversation_id: event.conversation_id, event_type: event.type, field, before, after };
  });
  await fs.mkdir(path.join(root, 'reports'), { recursive: true });
  await fs.mkdir(path.join(root, 'artifacts'), { recursive: true });
  await fs.writeFile(path.join(root, 'reports/case_results.csv'), csvText(['case_id', 'role', 'observed_visible_ids', 'opened_conversation_id', 'sla_labels'], caseRows));
  await fs.writeFile(path.join(root, 'reports/socket_event_audit.csv'), csvText(['event_id', 'conversation_id', 'event_type', 'field', 'before', 'after'], eventRows));
  await fs.writeFile(path.join(root, 'reports/focus_path.csv'), csvText(['order_index', 'locator', 'label'], focusRows));
  expect(caseRows).toHaveLength(5);
  expect(eventRows).toHaveLength(4);
  expect(focusRows).toHaveLength(5);
});
